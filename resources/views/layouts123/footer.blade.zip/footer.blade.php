<footer class="footer text-center text-sm-center">
                    &copy; <script>
                        document.write(new Date().getFullYear())
                    </script> Developed  by <span class="text-muted d-none d-sm-inline-block"><a href="#" target="_blank"> AII <img src="{{ asset('assets/images/aiiLogo.png') }}"  alt="logo-small" class="logo-sm" width="30" height="30"></img></a></span>
                </footer><!--end footer-->